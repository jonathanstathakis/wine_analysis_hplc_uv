"""
Baseline correction.
"""
