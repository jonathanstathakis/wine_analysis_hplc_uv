"""
A module to test current modifications to cellartracker cleaner based on whether a newly generated cleaned table equals the 'original'.
"""
import duckdb as db
import pandas as pd
import numpy as np
from wine_analysis_hplc_uv import definitions

# from wine_analysis_hplc_uv.cellartracker_methods.ct_cleaner
from wine_analysis_hplc_uv.core import ct_to_db
import os
from wine_analysis_hplc_uv.cellartracker_methods.ct_cleaner import CTCleaner


def get_o_cct(con):
    o_cct = con.sql(f"SELECT * FROM {definitions.CLEAN_CT_TBL_NAME}").df()
    return o_cct


def build_new_cct(db_path, ct_tbl):
    # cellar_tracker
    un = os.environ.get("CELLAR_TRACKER_UN")
    pw = os.environ.get("CELLAR_TRACKER_PW")
    ct_to_db.ct_to_db(ct_tbl=ct_tbl, db_filepath=db_path, un=un, pw=pw)


def clean_new_cct(ct_tbl, db_path):
    ct_cleaner = CTCleaner(db_path=db_path, raw_tbl_name=ct_tbl)
    ct_cleaner.to_db(db_filepath=db_path, tbl_name=definitions.CLEAN_CT_TBL_NAME)


def get_new_c_cellartracker(con):
    n_cct = con.sql("SELECT * FROM c_cellar_tracker").df()
    return n_cct


def cleanup(db_path):
    if os.path.exists(db_path):
        os.remove(db_path)

def compare_cct(o_cct, n_cct):
    cct = {
            'o_cct':o_cct,
           #'n_cct':n_cct
           }
    for k, t in cct.items():
        print(f"##{k}")
        print(t.loc[0:10,['vintage','name','wine']])

def main():

    new_db_path = os.path.join(os.path.dirname(__file__), "test_new_cct.db")
    new_ct_tblname="new_ct"
    kws = dict(db_path=new_db_path, ct_tbl=new_ct_tblname)

    build_new_cct(**kws)
    clean_new_cct(**kws)

    con1 = db.connect(definitions.DB_PATH)
    con2 = db.connect(new_db_path)
    print("## old CT")
    con1.sql(f"describe {definitions.CLEAN_CT_TBL_NAME}").show()
    print("## New CT")
    con2.sql(f"describe {new_ct_tblname}").show()
    o_cct = get_o_cct(con1)
    n_cct = get_new_c_cellartracker(con2)
    #compare_cct(o_cct, n_cct)

    cleanup(new_db_path)

    


if __name__ == "__main__":
    main()
