### Dataset

A CUPRAC red wine dataset at 450nm has been constructed and stored to parquet file in [processing_cup_rw_dset](./processing_cup_rw_dset.ipynb). The filepath to the data file is stored in  .

