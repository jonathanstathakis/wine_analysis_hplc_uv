# PCA README

## Description

This subpackage is intended as an application of the PCA model to investigate clustering of wine samples based on categorical variables, primarily varietal.

## Associated files

Main module found [here](pca.py).
Test module found [here](../../../tests/test_modeling/test_pca/test_pca.py).

