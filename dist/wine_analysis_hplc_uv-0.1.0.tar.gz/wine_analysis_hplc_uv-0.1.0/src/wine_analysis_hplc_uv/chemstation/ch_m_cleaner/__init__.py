"""
A module containing methods to clean chemstation metadata table to enable joins with sample tracker
"""
