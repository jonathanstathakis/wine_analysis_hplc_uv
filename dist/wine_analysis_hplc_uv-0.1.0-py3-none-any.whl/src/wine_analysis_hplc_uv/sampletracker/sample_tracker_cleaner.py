"""
Basic clean on sample_tracker. as of 2023-04-19 doesn't need it, but good to be safe for future issues.
"""
import html
import os

import duckdb as db
import pandas as pd

from wine_analysis_hplc_uv.db_methods import db_methods
from wine_analysis_hplc_uv.df_methods import df_cleaning_methods


def clean_sample_tracker_table(
    db_filepath: str,
    tbl_name: str,
) -> None:
    clean_tbl_name = "cleaned_" + tbl_name

    print("generating raw_sample_tracker_table from db..\n")

    with db.connect(db_filepath) as con:
        raw_sample_tracker_df = con.sql(f"SELECT * FROM {tbl_name}").df()

    cleaned_sample_tracker_df = sample_tracker_df_cleaner(raw_sample_tracker_df)

    write_clean_sample_tracker_to_db(
        cleaned_sample_tracker_df, db_filepath, clean_tbl_name
    )

    return None


def sample_tracker_df_cleaner(df):
    """
    apply df_string_cleaner, strips and lowers column, index and values of the passed dataframe.
    """

    df = df_cleaning_methods.df_string_cleaner(df)

    return df


def write_clean_sample_tracker_to_db(
    df: pd.DataFrame, db_filepath: str, table_name: str
) -> None:
    schema = """
        id VARCHAR,
        vintage VARCHAR,
        name VARCHAR,
        open_date DATE,
        sampled_date DATE,
        added_to_cellartracker VARCHAR,
        notes VARCHAR,
        size INTEGER
    """

    col_names = """
        id,
        vintage,
        name,
        open_date,
        sampled_date,
        added_to_cellartracker,
        notes,
        size
    """

    db_methods.write_df_to_table(
        df,
        db_filepath,
        table_name,
        schema,
        table_column_names=col_names,
        df_column_names=col_names,
    )

    db_methods.display_table_info(db_filepath, table_name)

    return None


def main():
    return None


if __name__ == "__main__":
    main()
