# Project README



## PCA Modelling

PCA modelling package is [here](src/wine_analysis_hplc_uv/modeling/pca.py)