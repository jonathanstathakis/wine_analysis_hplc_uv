"""
The package containing the ETL, deconvolution and analysis of my wine dataset
"""
