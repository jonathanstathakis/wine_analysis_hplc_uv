"""
A now defunct (2024-05-18) OOP - based approach to making modifications to the database library. A greater understanding of sql transactions and development has rendered the safeguards provided by these structures moot.
"""

from deprecated import deprecated

deprecated(
    "This module is obsolete, having been replaced by `post_build_library` and its associated sql scripts.."
)
