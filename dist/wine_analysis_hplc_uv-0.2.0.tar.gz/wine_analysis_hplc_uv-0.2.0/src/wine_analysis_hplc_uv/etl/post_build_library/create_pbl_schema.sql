-- create the schema to contain the pbl tables

create schema pbl;