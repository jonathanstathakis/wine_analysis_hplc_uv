"""
Contains implementations of fit functions in various libraries
"""
