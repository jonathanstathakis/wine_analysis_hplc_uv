"""
Need to:
- [ ] rewrite get_sc_df to draw directly from 'clean' tables rather than super table.
- create the new table as a view, compare it to the existing sc_df

To form sc_tbl we need to form the super table in a subquery, no doubt.
"""
%reload_ext autoreload
%autoreload 2

import duckdb as db
from wine_analysis_hplc_uv import definitions
import db_methods
from test_func import a_func
from mydevtools.function_timer import timeit
import pandas as pd
print(a_func())

class CompareSCTbls:
    def __init__(self, con):
        self.con = con
        self.old_sc_df = db_methods.get_sc_df(
            con=con,
            wavelength=[450],
            mins=(0, 5),
            detection=["cuprac"],
            )

        print(self.old_sc_df)


def new_get_sc_df(con):
    """
    a new sql query function made in the image of db_methods.get_sc_df but drawing from the cleaned base tables rather than super table.
    """
    query = f"""
    CREATE OR REPLACE VIEW nsuprtbl
    AS
    SELECT *
    FROM
    {definitions.CLEAN}
    """

def st_ct_join(con):
    query = """
    CREATE OR REPLACE VIEW 
    """
    from wine_analysis_hplc_uv.core.super_table_pipe.cellartracker_fuzzy_join import cellar_tracker_fuzzy_join
    
    ct_df = con.sql(f"SELECT * FROM {definitions.CLEAN_CT_TBL_NAME}").df()
    st_df = con.sql(f"SELECT * FROM {definitions.CLEAN_ST_TBL_NAME}").df()
    
    fuzzy_df = cellar_tracker_fuzzy_join(st_df, ct_df)
    # join on vintage__st, name_st
    
    join_st_df = (
        st_df
        .assign(left_st_join_key=lambda x: x['vintage']+" "+x['name'])
        .pipe(pd.merge, right=fuzzy_df[['join_key_st','join_key_ct']], left_on='left_st_join_key', right_on='join_key_st')
        .drop(['join_key', 'left_st_join_key', 'join_key_st'], axis=1)
        )
    
    # now join back with cellartracker through the join key
    print("new st ct join on forein key")
    join_st_df = (
        join_st_df
        .pipe(pd.merge, right=ct_df.assign(st_join=lambda df: df['vintage'] + " " + df['name']), left_on='join_key_ct', right_on='st_join')
    )
    # print(join_st_df.describe())
    # join_st_df.info()
    print(join_st_df.sample(10))
    
    
    con.sql(f"describe {definitions.CLEAN_ST_TBL_NAME}").show()
    
    print(con.sql("show tables").show())
    
    print(
        con
          .sql(f"""
                  CREATE OR REPLACE TEMP TABLE stt
                  AS
                  SELECT * FROM {definitions.CLEAN_ST_TBL_NAME};
                  SELECT * FROM stt
                  """)
          .show()
          )
    
    print(con.sql("show tables").show())
    print(con.sql("DROP TABLE ct_st_join"))
    print(con.sql("show tables").show())
    ``

@timeit
def main():
    con = db.connect(definitions.DB_PATH)
    #compare = CompareSCTbls(con)
    st_ct_join(con)


if __name__ == "__main__":
    main()
